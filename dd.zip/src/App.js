import React from "react";
import { Route, Redirect,Switch } from "react-router-dom";
import Navbar from "./pages/LoginPage/Navbar";
import LoginPage from "./pages/LoginPage/LoginPage"
import Home from "./pages/LoginPage/Home";


const App=()=>{
return
(
    <>
<Navbar/>
<Switch>
<Route exact path="/" element={<Home/>} />
<Route exact path="/login" element={<LoginPage/>} />
</Switch>
    </>
)
}

export default App;