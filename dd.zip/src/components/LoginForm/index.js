// ## This is not required anymore in newer versions of React ##
// import React from 'react'

const LoginForm = () => {
  return (
    <div className='login-form-container'>Login Form</div>
  )
}

export default LoginForm