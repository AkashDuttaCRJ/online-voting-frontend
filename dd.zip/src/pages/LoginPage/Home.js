import React from "react";
const Home=()=>{
    return
    (
        <h1>Lorem34 jhjj hjgjgju bjgjgj jgjgjggjgjgjh
        </h1>
    )
}
export default Home;