// ## Add Everything related to Signup Page here ##

// ## This is not required anymore in newer versions of React ##
// import React from 'react'

const SingupPage = () => {
  return (
    <>
    <div>SignupPage</div>
    </>
  )
}

export default SingupPage;